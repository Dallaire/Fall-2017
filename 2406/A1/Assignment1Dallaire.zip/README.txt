OS: Windows 10 Pro 1703 Build: 15063.674

Visit http://localhost:3000/ or http://localhost:3000/assinment1.html to test, all songs accessed by text field.
//Couldnt figure out how to parse from the canvas to chordpro plain text.
