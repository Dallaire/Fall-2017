// Jacob Dallaire 100918375
#include "UI.h"

int main(){
  UI interface;
  interface.inittialize();
  return 0;
}
