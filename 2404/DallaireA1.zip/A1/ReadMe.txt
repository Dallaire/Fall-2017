//To decompress the files
unzip DallaireA1.zip

//To Compile
g++ -g -Wall -std=c++11 main.cpp songs.cpp UI.cpp playlists.cpp recordings.cpp users.cpp str_util.cpp

//To Run
./a.out
.read addData.txt
.read script.txt
