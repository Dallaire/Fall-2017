#include <string>

using namespace std;

class StrUtils{
	public:
	static string toUpperCase(string str);
  static string toTitleCase(string str);
};
