To Compile with g++:
>make clean
>make myApp

To Run:
>./myApp

